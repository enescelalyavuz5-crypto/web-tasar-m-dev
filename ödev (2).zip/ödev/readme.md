# Kişisel Blog Ödevi

Bu repo, **Web Teknolojileri ve Programlama (2025-2026)** dersi için hazırlanmıştır.  
Kişisel blog sayfasında hakkımda bilgiler, projelerim, resim ve video yer almaktadır.  

## 🌍 Site Adresi
📌 [https://kullaniciadi.github.io/kisisel-blog](https://kullaniciadi.github.io/kisisel-blog)

## 📂 İçerik
- `index.html` → Blog sayfası  
- `README.md` → Açıklamalar ve site linki  

## 🛠️ Kullanılan Teknolojiler
- HTML5  
- CSS3  
- GitHub Pages (yayınlama için)  

---
© 2025 Enes Celal Yavuz
